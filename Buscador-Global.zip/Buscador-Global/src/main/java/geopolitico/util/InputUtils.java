package geopolitico.util;

import java.util.Scanner;

/**
 * Utilitários para leitura e validação de entrada do usuário no console.
 *
 * <p>Extraídos de {@code Main} para garantir coesão: a classe principal
 * coordena o fluxo; este utilitário trata os detalhes de parsing de input.
 *
 * <p>Todos os métodos são estáticos — não há estado a manter.
 */
public final class InputUtils {

    private InputUtils() { /* utilitário, não instanciável */ }

    /**
     * Lê uma linha do scanner e converte para {@code long}.
     *
     * <p>Aceita separadores de milhar (ponto ou vírgula) e ignora espaços.
     * Retorna {@code 0} se a entrada estiver vazia ou inválida.
     *
     * @param scanner scanner ativo
     * @param prompt  texto exibido antes da leitura
     * @return valor lido, ou {@code 0} em caso de entrada vazia/inválida
     */
    public static long lerLong(Scanner scanner, String prompt) {
        System.out.print(prompt);
        String s = scanner.nextLine().trim();
        if (s.isEmpty()) return 0L;
        try {
            return Long.parseLong(s.replaceAll("[.,\\s]", ""));
        } catch (NumberFormatException e) {
            System.out.println("  Valor inválido — filtro ignorado.");
            return 0L;
        }
    }

    /**
     * Lê uma linha do scanner e converte para {@code double}.
     *
     * <p>Aceita tanto vírgula quanto ponto como separador decimal.
     * Retorna {@code 0.0} se a entrada estiver vazia ou inválida.
     *
     * @param scanner scanner ativo
     * @param prompt  texto exibido antes da leitura
     * @return valor lido, ou {@code 0.0} em caso de entrada vazia/inválida
     */
    public static double lerDouble(Scanner scanner, String prompt) {
        System.out.print(prompt);
        String s = scanner.nextLine().trim();
        if (s.isEmpty()) return 0.0;
        try {
            return Double.parseDouble(s.replace(",", "."));
        } catch (NumberFormatException e) {
            System.out.println("  Valor inválido — filtro ignorado.");
            return 0.0;
        }
    }

    /**
     * Lê e valida a escolha de critério de ordenação e sentido (crescente/decrescente).
     *
     * @param scanner scanner ativo
     * @param prompt1 prompt para o critério
     * @param prompt2 prompt para a ordem
     * @return array {@code [criterio, ordem]} onde criterio ∈ {1,2,3} e ordem ∈ {1,2},
     *         ou {@code null} se o usuário fornecer entrada inválida
     */
    public static int[] lerOrdenacao(Scanner scanner, String prompt1, String prompt2) {
        System.out.print(prompt1);
        String c = scanner.nextLine().trim();
        System.out.print(prompt2);
        String o = scanner.nextLine().trim();

        int criterio = switch (c) {
            case "1" -> 1; case "2" -> 2; case "3" -> 3; default -> -1;
        };
        int ordem = switch (o) {
            case "1" -> 1; case "2" -> 2; default -> -1;
        };

        if (criterio == -1 || ordem == -1) {
            System.out.println("  Opção inválida.");
            return null;
        }
        return new int[]{criterio, ordem};
    }
}
