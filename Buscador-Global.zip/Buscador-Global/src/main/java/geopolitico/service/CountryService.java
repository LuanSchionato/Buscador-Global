package geopolitico.service;

import geopolitico.model.Country;

import java.util.List;
import java.util.Optional;

/**
 * Contrato do serviço de consulta a dados geopolíticos de países.
 *
 * <p>A separação entre interface e implementação ({@link RestCountriesClient})
 * permite:
 * <ul>
 *   <li><strong>Testabilidade</strong>: testes unitários podem injetar mocks
 *       sem depender de rede.</li>
 *   <li><strong>Substituição de fonte</strong>: trocar a API RestCountries por
 *       outra fonte (banco local, arquivo JSON) sem alterar a lógica de negócio.</li>
 * </ul>
 *
 * <p>Todas as implementações devem lançar {@link geopolitico.exception.ApiException}
 * em caso de falha de infraestrutura (rede, parsing), nunca exceções genéricas.
 */
public interface CountryService {

    /**
     * Localiza um país pelo nome comum em inglês.
     *
     * @param nome nome do país (ex.: "Brazil", "France")
     * @return {@link Optional} com o país, ou vazio se não encontrado
     */
    Optional<Country> buscarPais(String nome);

    /**
     * Retorna a lista completa de países da fonte de dados.
     *
     * @return lista de países; nunca {@code null}
     */
    List<Country> buscarTodos();

    /**
     * Retorna os países de um continente/região específica.
     *
     * @param regiao nome da região (ex.: "Africa", "Asia", "Europe")
     * @return lista de países; nunca {@code null}
     */
    List<Country> buscarPorRegiao(String regiao);
}
