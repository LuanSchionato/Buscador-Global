package geopolitico.exception;

/**
 * Exceção lançada quando a comunicação com a API RestCountries falha.
 *
 * <p>Diferencia erros de rede de outros tipos de falha, permitindo
 * que as camadas superiores respondam adequadamente (ex.: mensagem
 * amigável ao usuário em vez de stack trace).
 */
public class ApiException extends RuntimeException {

    private final int statusCode;

    public ApiException(String message) {
        super(message);
        this.statusCode = -1;
    }

    public ApiException(String message, int statusCode) {
        super(message + " (HTTP " + statusCode + ")");
        this.statusCode = statusCode;
    }

    public ApiException(String message, Throwable cause) {
        super(message, cause);
        this.statusCode = -1;
    }

    /** @return código HTTP de resposta, ou {@code -1} se não aplicável (ex.: timeout) */
    public int getStatusCode() {
        return statusCode;
    }
}
