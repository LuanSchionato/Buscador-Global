package geopolitico.model;

/**
 * Resultado agregado de uma expressão geopolítica (país, região ou combinação deles).
 *
 * <p>Utilizado tanto para exibição simples quanto para comparação bilateral.
 * Implementado como {@code record} para imutabilidade garantida em tempo de compilação.
 *
 * <p>Exemplo de expressão que gera este objeto:
 * <pre>
 *   "Africa - UnitedStates"  →  GrupoResultado("Africa - United States", pop, area, n, true)
 * </pre>
 *
 * @param label        rótulo legível da expressão (ex.: "Africa - United States")
 * @param populacao    população total (pode ser negativa em subtrações)
 * @param area         área total em km² (pode ser negativa em subtrações)
 * @param numeroPaises contagem de entidades (países/regiões); sem semântica clara em subtrações
 * @param temSubtracao {@code true} quando a expressão usa o operador {@code -}
 */
public record GrupoResultado(
        String label,
        long populacao,
        double area,
        int numeroPaises,
        boolean temSubtracao
) {

    /** @return densidade demográfica agregada, ou {@code 0.0} se área inválida */
    public double getDensidade() {
        return area > 0 ? (double) populacao / area : 0.0;
    }

    /** @return {@code true} se ambos população e área são positivos (resultado faz sentido físico) */
    public boolean temValoresPositivos() {
        return populacao > 0 && area > 0;
    }
}
