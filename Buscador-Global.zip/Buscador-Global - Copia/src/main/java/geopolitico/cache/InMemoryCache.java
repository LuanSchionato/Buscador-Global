package geopolitico.cache;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Cache em memória simples e thread-safe para respostas da API.
 *
 * <p>Evita chamadas redundantes à rede dentro de uma mesma sessão do programa.
 * Por exemplo, "buscar todos os países" é uma operação cara (~250 KB de JSON)
 * que não precisa ser repetida quando o usuário solicita uma segunda listagem.
 *
 * <p>Usa LRU (Least Recently Used) com capacidade configurável para evitar
 * crescimento ilimitado da memória.
 *
 * @param <V> tipo do valor armazenado
 */
public final class InMemoryCache<V> {

    private final Map<String, V> store;

    /**
     * @param capacidadeMaxima número máximo de entradas; ao exceder, a entrada
     *                         mais antiga é descartada (política LRU)
     */
    public InMemoryCache(int capacidadeMaxima) {
        this.store = Collections.synchronizedMap(
                new LinkedHashMap<>(16, 0.75f, true) {
                    @Override
                    protected boolean removeEldestEntry(Map.Entry<String, V> eldest) {
                        return size() > capacidadeMaxima;
                    }
                }
        );
    }

    /**
     * Recupera um valor do cache.
     *
     * @param chave chave de busca
     * @return {@link Optional} com o valor, ou vazio se ausente
     */
    public Optional<V> get(String chave) {
        return Optional.ofNullable(store.get(chave));
    }

    /**
     * Armazena um valor no cache.
     *
     * @param chave  chave de armazenamento
     * @param valor  valor a armazenar
     */
    public void put(String chave, V valor) {
        store.put(chave, valor);
    }

    /** Remove todas as entradas do cache. */
    public void limpar() {
        store.clear();
    }

    /** @return número de entradas atualmente no cache */
    public int tamanho() {
        return store.size();
    }
}
